/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flexbox;

/**
 *
 * @author Dylan Ritchings
 */
public abstract class Box {
    private int grade, amount;
    private double width, length, height;
//
    protected double[] costPerGrade = {0.55,0.65,0.82,0.98,1.5};
//
//    private int colourAmount;
    private boolean sealableTop;

//    private double[] additonalCosts = {0.12,0.15,0.13,0.12,0.1};

    public Box() {
    }

    public Box(int cGrade, int cAmount, double cWidth, double cLength, double cHeight, boolean cSealableTop){
        grade = cGrade;
        amount = cAmount;
        width = cWidth;
        length = cLength;
        height = cHeight;
//        colourAmount = cColourAmount;
//        reinforcedBottom = cReinforcedBottom;
//        reinforcedCorners = cReinforcedCorners;
        sealableTop = cSealableTop;
    }

//    protected abstract String getBoxType();

    public abstract double calcCost();

    public int getGrade(){
      return grade;
    }

    public void setGrade(int cGrade){
      grade = cGrade;
    }

//    public double getWidth(){
//      return width;
//    }

    public void setWidth(double cWidth){
      width = cWidth;
    }

//    public double getHeight(){
//      return height;
//    }

    public void setHeight(double cHeight){
      height = cHeight;
    }

//    public double getLength(){
//      return length;
//    }

    public void setLength(double cLength){
      length = cLength;
    }

    public double calcSurfaceArea() {
        double sideArea = length * height;
        double endArea = width * height;
        return (4 * sideArea) + (2 * endArea);
    }

    public int getAmount() {
        return amount;
    }
    
    public void setAmount(int cAmount) {
        amount = cAmount;
    }
    
    public boolean getSealableTop() {
        return sealableTop;
    }
    
    public double calcBaseCost() {
        return costPerGrade[getGrade() - 1] * calcSurfaceArea() * getAmount();
    }

}