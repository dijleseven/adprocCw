/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flexbox;

/**
 *
 * @author josh
 */
public class BoxType1 extends Box {
    
    public BoxType1(int cGrade, int cAmount, double cWidth, double cLength, double cHeight, boolean cSealableTop) {
        super(cGrade, cAmount, cWidth, cLength, cHeight, cSealableTop);
    }
    
    @Override
    public double calcCost() {
        
        return (getSealableTop())?(calcBaseCost()*1.1):calcBaseCost();
        
    }
    
}
