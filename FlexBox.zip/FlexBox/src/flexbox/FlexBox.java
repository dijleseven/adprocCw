/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flexbox;

/**
 *
 * @author josh
 */
public class FlexBox {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BoxType1 box1 = new BoxType1(2, 500, 0.6, 0.8, 1.0, true);
        System.out.println(box1.calcCost());
    }
    
}
