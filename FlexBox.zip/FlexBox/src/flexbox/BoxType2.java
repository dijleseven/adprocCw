/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flexbox;

/**
 *
 * @author josh
 */
public class BoxType2 extends Box {
    
    private String colour;
    
    public BoxType2(int cGrade, int cAmount, double cWidth, double cLength, double cHeight, boolean cSealableTop, String cColour) {
        super(cGrade, cAmount, cWidth, cLength, cHeight, cSealableTop);
        colour = cColour;
    }
    
    @Override
    public double calcCost() {
        return (getSealableTop() && !colour.equals(""))?(calcBaseCost() * 1.1 + calcBaseCost() * 1.12):(getSealableTop())?(calcBaseCost() * 1.1):(!colour.equals(""))?(calcBaseCost() * 1.12):calcBaseCost();
    }
    
}
